import { getCurrentScope, ref, watch } from 'vue'
import { useDebounceFn, useThrottleFn } from '@vueuse/core'
import { ExMap, clone, createBus, isDev, isStr, multiPromise, now } from '../util'

const ListenerBus = new ExMap()
const SubListeners = new ExMap()
const ExecutorBus = new ExMap()
const SubExecutors = new ExMap()
const KeyMapper = new Map()

const createListenerBus = (key) => {
  return ListenerBus.computeIfAbsent(key, createBus.bind(null, key))
}

const createWardenBus = createListenerBus

const createExecutorBus = (key) => {
  return ExecutorBus.computeIfAbsent(key, createBus.bind(null, key))
}

const createInvokerBus = createExecutorBus

function unique(keys) {
  if (Array.isArray(keys)) {
    const [key, subKey] = keys
    const keyStr = `${key?.description ?? key}-${subKey}`

    if (KeyMapper.has(keyStr))
      return [KeyMapper.get(keyStr), true]

    const keySym = Symbol(keyStr)
    KeyMapper.set(keyStr, keySym)
    return [keySym, true]
  }
  return [keys, false]
}

/**
 * 创建事件总线，用于监听表单数据变化并触发事件
 *
 * @param {Symbol|string} key - 事件总线的标识符，推荐使用 Symbol 类型
 * @param {Object} [options] - 可选配置参数
 * @param {number} [options.debounce] - 防抖延迟时间（毫秒），与 throttle 不能同时使用
 * @param {number} [options.throttle] - 节流间隔时间（毫秒），与 debounce 不能同时使用
 * @param {string|string[]} [options.props] - 监听的属性，可以是字符串或字符串数组
 * @param {Function} [options.downstream] - 下游处理函数，用于处理数据
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @description
 * 此函数创建一个事件总线，当表单数据发生变化时，会通过事件总线触发事件。
 * 支持防抖和节流功能，避免频繁触发事件。
 *
 * @throws {Error} 当同时配置了 debounce 和 throttle 选项时抛出错误
 *
 * @example
 * // index.js
 * const formData = formDataRef({
 *   name: 'foo',
 *   age: 18,
 * }).warden('form-data-change')
 * formData.name = 'boo'
 *
 * // receiver.js
 * const bus = useEventBus('form-data-change')
 * bus.on((data) => {
 *   console.log(data) // { name: 'boo', age: 18 }
 * })
 */
export function warden(keys, { flush = 'pre', debounce, maxWait, throttle, props, downstream } = {}) {
  const { ctx, proxy, origin } = this

  const [key, isSub] = unique(keys)

  if (isStr(key))
    console.warn(`use Symbol instead of String "${key}"`)

  if (debounce && throttle)
    throw new Error('debounce and throttle cannot be used at the same time')

  const emit = (bus, dto) => {
    if (bus.size)
      bus.emit(dto)
  }

  const emitAll = (() => {
    const bus = createWardenBus(key)
    let subBusses

    return isSub
      ? emit.bind(null, bus)
      : (val) => {
          if (!subBusses)
            subBusses = SubListeners.get(key)
          emit(bus, val)
          subBusses?.forEach(bus => bus.emit(bus, val))
        }
  })()

  const buf = ref(null)
  watch(buf, emitAll, { flush })

  const fn = data => buf.value = downstream ? downstream(data) : data
  const originHandler = debounce
    ? useDebounceFn(fn, debounce, maxWait ? { maxWait } : undefined)
    : throttle
      ? useThrottleFn(fn, throttle)
      : fn

  const handler = (data) => {
    if (ctx.silentUpdate)
      return

    originHandler(data)
  }

  const options = { flush: 'sync' }

  if (!props)
    watch(origin, handler, { deep: true, ...options })

  else if (Array.isArray(props))
    watch(() => props.map(key => origin.value[key]), handler, options)

  else if (isStr(props)) {
    if (!(props in ctx.defaultValue))
      throw new Error(`unknown property "${props}"`)

    watch(() => origin.value[props], handler, options)
  }

  return proxy
}

export function executor(keys, interceptor) {
  const { ctx, proxy } = this

  const [key, isSub] = unique(keys)

  if (isStr(key))
    console.warn(`use Symbol instead of String "${key}"`)

  const bus = createExecutorBus(key)
  if (isSub) {
    const busPool = SubExecutors.computeIfAbsent(keys[0], [])
    if (!busPool.includes(bus))
      busPool.push(bus)
  }

  const description = key?.description ?? key

  const handler = async ({ resolve, reject, ...dto }) => {
    if (!('fn' in dto))
      return
    const info = clone(dto)

    let res
    try {
      if (interceptor) {
        const cb = interceptor(info)
        const val = cb instanceof Promise ? await cb : cb
        if (val === false) {
          res = {
            ok: false,
            msg: `"${description}" intercepted: ${info.fn}`,
            data: null,
          }
          return
        }
      }

      const cb = proxy[info.fn]?.(...info.args)
      let val = cb instanceof Promise ? await cb : cb
      // 不允许通过这种方式获取代理对象
      if (val === proxy)
        val = null
      res = {
        ok: true,
        msg: null,
        data: val,
      }
    }
    catch (err) {
      res = {
        ok: false,
        msg: err.message,
        data: null,
      }
    }
    finally {
      res.ok ? resolve(res.data) : reject(res.msg)
      Object.assign(info.event, {
        respTime: now(),
        result: res,
      })
      if (isDev) {
        // 只存储最新的100条记录
        if (ctx.logs.length > 100)
          ctx.logs.shift()
        ctx.logs.push(info)
      }
    }
  }

  ctx.cleanups.push(bus.on(handler))

  return proxy
}

export function useInvoker(keys) {
  const [key, isSub] = unique(keys)

  const emit = (bus, dto) => {
    const event = {
      callTime: now(),
      source,
      trace,
    }
    const { promises, resolve, reject } = multiPromise(bus.size)
    bus.emit({ ...dto, event, resolve, reject })
    return promises
  }

  const emitAll = (() => {
    const bus = createInvokerBus(key)
    let subBusses

    return isSub
      ? emit.bind(null, bus)
      : (dto) => {
          if (!subBusses)
            subBusses = SubExecutors.get(key)
          const proms = emit(bus, dto)
          subBusses?.forEach(bus => proms.push(emit(bus, dto)))
          return proms
        }
  })()

  const extractVueFilePath = (errorStack = '') => {
    const regex = /src\/.*?\.vue(?=\?|$)/
    const match = errorStack.match(regex)
    return match ? match[0] : null
  }

  const callStack = isDev ? new Error(key?.description ?? key).stack.replace('Error', 'Trace') : undefined
  const source = isDev ? extractVueFilePath(callStack?.split('\n')?.[2]) : undefined
  /* eslint-disable-next-line no-console */
  const trace = isDev ? console.log.bind(globalThis, callStack) : undefined

  const promTemplate = async (promFn, fn, ...args) => {
    return new Promise((resolve, reject) => {
      const proms = emitAll({ fn, args })
      Promise[promFn](proms).then(resolve).catch(reject)
    })
  }

  const invoke = promTemplate.bind(null, 'race')

  const fns = ['all', 'allSettled', 'any', 'race']
  for (const fn of fns)
    invoke[fn] = promTemplate.bind(null, fn)

  return invoke
}

export function useListener(keys) {
  const [key, isSub] = unique(keys)

  const bus = createListenerBus(key)
  if (isSub) {
    const busPool = SubListeners.computeIfAbsent(keys[0], [])
    if (!busPool.includes(bus))
      busPool.push(bus)
  }

  const scope = getCurrentScope()

  return {
    on(handler) {
      const off = bus.on(handler)
      scope?.cleanups?.push(off)
    },
    off: bus.off,
  }
}
