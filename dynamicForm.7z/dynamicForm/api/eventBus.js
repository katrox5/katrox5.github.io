import { debounceFilter, throttleFilter, useEventBus, watchWithFilter } from '@vueuse/core'
import { isDev, now } from '../util'

/**
 * 创建事件总线，用于监听表单数据变化并触发事件
 *
 * @param {Symbol|string} key - 事件总线的标识符，推荐使用 Symbol 类型
 * @param {Object} [options] - 可选配置参数
 * @param {number} [options.debounce] - 防抖延迟时间（毫秒），与 throttle 不能同时使用
 * @param {number} [options.throttle] - 节流间隔时间（毫秒），与 debounce 不能同时使用
 * @param {string|string[]} [options.props] - 监听的属性，可以是字符串或字符串数组
 * @param {Function} [options.downstream] - 下游处理函数，用于处理数据
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @description
 * 此函数创建一个事件总线，当表单数据发生变化时，会通过事件总线触发事件。
 * 支持防抖和节流功能，避免频繁触发事件。
 *
 * @throws {Error} 当同时配置了 debounce 和 throttle 选项时抛出错误
 *
 * @example
 * // index.js
 * const formData = formDataRef({
 *   name: 'foo',
 *   age: 18,
 * }).warden('form-data-change')
 * formData.name = 'boo'
 *
 * // receiver.js
 * const bus = useEventBus('form-data-change')
 * bus.on((data) => {
 *   console.log(data) // { name: 'boo', age: 18 }
 * })
 */
export function warden(key, { debounce, throttle, props, downstream } = {}) {
  const { ctx, proxy, origin } = this

  if (typeof key === 'string')
    console.warn(`use Symbol instead of String "${key}"`)

  if (debounce && throttle)
    throw new Error('debounce and throttle cannot be used at the same time')

  const bus = useEventBus(key)
  const handler = (data) => {
    if (ctx.silentUpdate)
      return ctx.silentUpdate = false

    data = downstream ? downstream(data) : data
    bus.emit(data)
  }

  if (!props) {
    watchWithFilter(origin, handler, {
      deep: true,
      eventFilter: debounce ? debounceFilter(debounce) : throttle ? throttleFilter(throttle) : undefined,
    })
  }
  else if (typeof props === 'string') {
    if (!(props in ctx.defaultValue)) {
      console.warn(`unknown property "${props}"`)
      return proxy
    }
    watchWithFilter(() => origin.value[props], handler, {
      eventFilter: debounce ? debounceFilter(debounce) : throttle ? throttleFilter(throttle) : undefined,
    })
  }
  else if (Array.isArray(props)) {
    watchWithFilter(() => props.map(key => origin.value[key]), handler, {
      eventFilter: debounce ? debounceFilter(debounce) : throttle ? throttleFilter(throttle) : undefined,
    })
  }
  return proxy
}

export function executor(key, interceptor) {
  const { ctx, proxy } = this

  if (typeof key === 'string')
    console.warn(`use Symbol instead of String "${key}"`)

  const description = key?.description ?? key
  const bus = useEventBus(key)

  bus.on(async ({ resolve, reject, ...obj }) => {
    if (!('fn' in obj))
      return

    let res
    try {
      if (interceptor) {
        const cb = interceptor(obj)
        const val = cb instanceof Promise ? await cb : cb
        if (val === false) {
          res = {
            ok: false,
            msg: `"${description}" intercepted: ${obj.fn}`,
            data: null,
          }
          return
        }
      }

      const cb = proxy[obj.fn]?.(...obj.args)
      let val = cb instanceof Promise ? await cb : cb
      // 不允许通过这种方式获取代理对象
      val = val === proxy ? null : val
      res = {
        ok: true,
        msg: null,
        data: val,
      }
    }
    catch (err) {
      res = {
        ok: false,
        msg: err.message,
        data: null,
      }
    }
    finally {
      res.ok ? resolve(res.data) : reject(res.msg)
      Object.assign(obj.event, {
        respTime: now(),
        result: res,
      })
      // 只存储最新的100条记录
      if (ctx.logs.length > 100)
        ctx.logs.shift()
      ctx.logs.push(obj)
    }
  })

  return proxy
}

const Bus = new Map()

export function useInvoker(key) {
  let bus
  ;(bus = Bus.get(key) ?? useEventBus(key)) && Bus.set(key, bus)

  const extractVueFilePath = (errorStack = '') => {
    const regex = /src\/.*?\.vue(?=\?|$)/
    const match = errorStack.match(regex)
    return match ? match[0] : null
  }

  const callStack = isDev ? new Error(key?.description ?? key).stack : undefined
  const source = isDev ? extractVueFilePath(callStack?.split('\n')?.[2]) : undefined

  return async function (fn, ...args) {
    return new Promise((resolve, reject) => {
      const event = {
        callTime: now(),
        source,
        trace: console.log.bind(globalThis, callStack),
      }
      bus.emit({ fn, args, event, resolve, reject })
    })
  }
}
