import { globalCtx } from '../ctx'
import { isDev } from '../util'

export function getItems(formName = 'default') {
  const { ctx } = this
  return ctx.formItems[formName]
}

export function getRules(formName = 'default') {
  const { ctx } = this
  return ctx.formRules[formName]
}

export function getLogs() {
  const { ctx } = this
  return isDev ? ctx.logs : undefined
}

export function getCustomTypes() {
  const { ctx } = this
  return ctx.customTypes
}

export function getGlobalCustomTypes() {
  return globalCtx.customTypes
}
