export function getItems(formName = 'default') {
  const { ctx } = this
  return ctx.formItems[formName]
}

export function getRules(formName = 'default') {
  const { ctx } = this
  return ctx.formRules[formName]
}

export function getLogs() {
  const { ctx } = this
  return ctx.logs
}
