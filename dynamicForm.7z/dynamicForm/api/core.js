import { ref } from 'vue'
import { watchWithFilter } from '@vueuse/core'
import { debounceFilter, isComponent, isSpKey, isStr, isXml, reservedTypes } from '../util'

const isSlotKey = isSpKey

function filterSpKeys(obj) {
  const res = { sp: {} }
  for (const key in obj) {
    if (isSpKey(key)) {
      res.sp[key] = obj[key]
    }
    else {
      res[key] = obj[key]
    }
  }
  return res
}

const ACTION_MAP = {
  input: '输入',
  select: '选择',
  radio: '选择',
  checkbox: '选择',
  cascader: '选择',
}

export function useDefine() {
  let unwatch
  return function (itemsGetter, { defaultRequired = true, formName = 'default' } = {}) {
    const { ctx, proxy } = this

    unwatch?.()
    unwatch = watchWithFilter(itemsGetter, (formItems) => {
      const tempFormItems = []
      const tempFormRules = {}

      for (const [key, val] of Object.entries(formItems)) {
        const {
          validator,
          required,
          message,
          trigger,
          ...keys
        } = val
        const {
          sp,
          ...item
        } = filterSpKeys(keys)

        if (isSlotKey(key))
          item.slot = key.slice(1)
        else
          item.prop = key

        tempFormItems.push(item)

        if (!item.prop)
          continue

        const rule = []
        // 若 defaultRequired 为 true，为没有设置 required = false 的 item 生成校验器
        // 若 defaultRequired 为 false，则只生成 required 为 true 的 item 的校验器
        if ((defaultRequired && required !== false) || (!defaultRequired && required)) {
          const propName = !isComponent(item.label) && !isXml(item.label) && isStr(item.label) ? item.label : ''
          rule.push({
            required: true,
            message: message ?? `请${ACTION_MAP[item.type] ?? '补充'}${propName}`,
          })
        }
        // 转译 validator 为校验器
        if (validator) {
          rule.push({
            validator(_, value, callback) {
              const cb = validator(value)
              const handler = val => callback(val ? new Error(val) : undefined)
              cb instanceof Promise
                ? cb.then(handler)
                : handler(cb)
            },
            trigger,
          })
        }

        tempFormRules[item.prop] = rule

        // 转译 $event 为 on.event
        if (item.type) {
          const eventHandlers = Object.entries(sp)
          if (eventHandlers.length) {
            item.on = eventHandlers.reduce((handlers, [key, handler]) => {
              const event = key.slice(1)
              const eventHanlder = [item.on?.[event], handler].flat().filter(Boolean)
              handlers[event] = eventHanlder.length === 1 ? eventHanlder.pop() : eventHanlder
              return handlers
            }, {})
          }
        }
      }

      if (ctx.formItems[formName])
        ctx.formItems[formName].value = tempFormItems
      else
        ctx.formItems[formName] = ref(tempFormItems)
      if (ctx.formRules[formName])
        ctx.formRules[formName].value = tempFormRules
      else
        ctx.formRules[formName] = ref(tempFormRules)
    }, {
      immediate: true,
      eventFilter: debounceFilter(200, { maxWait: 400 }),
    })

    return proxy
  }
}

export function register(component, key) {
  const { ctx, proxy } = this

  if (reservedTypes.includes(key))
    throw new Error(`can not use "${key}" as key`)

  ctx.customTypes.set(key, component)

  return proxy
}
