import { computed } from 'vue'
import { reactiveOmit, reactivePick } from '@vueuse/shared'

/**
 * 从表单数据中选择指定的字段，返回响应式对象
 *
 * @param {string[]} props - 要选择的字段名数组
 * @returns {Object} 包含指定字段的响应式对象
 *
 * @example
 * // 选择指定字段
 * const selectedData = formData.pick(['foo', 'boo'])
 */
export function pick(props) {
  const { origin } = this

  return reactivePick(origin.value, ...props)
}

/**
 * 从表单数据中排除指定的字段，返回响应式对象
 *
 * @param {string[]} props - 要排除的字段名数组
 * @returns {Object} 排除指定字段后的响应式对象
 *
 * @example
 * // 排除指定字段
 * const filteredData = formData.omit(['foo', 'boo'])
 */
export function omit(props) {
  const { origin } = this

  return reactiveOmit(origin.value, ...props)
}

/**
 * 为指定字段设置格式化函数
 *
 * @param {string} prop - 要格式化的字段名
 * @param {Function} formatter - 格式化函数，接收字段值作为参数并返回格式化后的值
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @example
 * // 为 foo 字段设置格式化函数，只显示后4位
 * formData.format('foo', val => val && val.slice(-4))
 *
 * // 使用时可通过 [$字段名] 访问格式化后的值
 * console.log(formData.$foo) // 打印格式化后的值
 */
export function format(prop, formatter) {
  const { ctx, proxy } = this

  ctx.formatters.set(prop, computed(() => formatter(proxy.value[prop])))
  return proxy
}
