import { computed } from 'vue'
import { reactiveOmit, reactivePick } from '@vueuse/shared'

/**
 * 从表单数据对象中反应式性地选取字段
 *
 * @param {string[]} ...props - 要选取的字段名
 * @returns {Object} 包含指定字段的响应式对象
 *
 * @example
 * const selectedData = formData.pick('foo', 'boo')
 */
export function pick(...props) {
  const { origin } = this

  return reactivePick(origin.value, ...props)
}

/**
 * 反应式地省略表单数据对象中的字段
 *
 * @param {string[]} ...props - 要排除的字段名
 * @returns {Object} 排除指定字段后的响应式对象
 *
 * @example
 * const filteredData = formData.omit('foo', 'boo')
 */
export function omit(...props) {
  const { origin } = this

  return reactiveOmit(origin.value, ...props)
}

/**
 * 为指定字段设置格式化器
 *
 * @param {string} prop - 要格式化的字段名
 * @param {Function} formatter - 格式化函数，接收字段值作为参数并返回格式化后的值
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @example
 * formData.format('foo', val => val && val.slice(-4))
 *
 * // 使用时可通过 [$字段名] 访问格式化后的值
 * console.log(formData.$foo) // 显示字段 foo 的后4位
 */
export function format(prop, formatter) {
  const { ctx, proxy } = this

  ctx.formatters.set(prop, computed(() => formatter(proxy.value[prop])))
  return proxy
}
