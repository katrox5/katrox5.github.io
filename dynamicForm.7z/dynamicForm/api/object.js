/**
 * 获取表单数据对象的所有键值对数组
 *
 * @returns {Array<Array>} 返回包含 [key, value] 键值对的数组
 *
 * @example
 * const entriesArray = formData.entries()
 * // 如: [['foo', null], ['boo', undefined], ...]
 */
export function entries() {
  const { proxy } = this
  return Object.entries(proxy.value)
}

/**
 * 获取表单数据对象的所有键名数组
 *
 * @returns {Array<string>} 返回包含所有键名的数组
 *
 * @example
 * const keysArray = formData.keys()
 * // 如: ['foo', 'boo', ...]
 */
export function keys() {
  const { proxy } = this
  return Object.keys(proxy.value)
}

/**
 * 获取表单数据对象的所有值数组
 *
 * @returns {Array<any>} 返回包含所有字段值的数组
 *
 * @example
 * const valuesArray = formData.values()
 * // 如: [null, undefined, ...]
 */
export function values() {
  const { proxy } = this
  return Object.values(proxy.value)
}

/**
 * 将表单数据对象转换为 JSON 字符串
 * JSON.stringify: https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
 *
 * @param {Function|Array} replacer - 同 JSON.stringify 的第二个参数
 * @param {string|number} space -同 JSON.stringify 的第三个参数
 * @returns {string} 返回表单数据的 JSON 字符串表示
 *
 * @example
 * const jsonString = formData.stringify()
 * // 如: '{"foo":null,"boo":null,...}'
 * const formattedJson = formData.stringify(null, 2)
 */
export function stringify(...args) {
  const { proxy } = this
  return JSON.stringify(proxy.value, ...args)
}
