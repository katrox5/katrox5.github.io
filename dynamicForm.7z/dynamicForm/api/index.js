import { get, lay, reset, set, setIf, setIfPresent, setOmit, setPick } from './accessor'
import { entries, keys, stringify, values } from './object'
import { format, omit, pick } from './react'
import { executor, warden } from './eventBus'
import { bind, clearValidate, validate } from './form'
import { register, useDefine } from './core'
import { getCustomTypes, getGlobalCustomTypes, getItems, getLogs, getRules } from './getCtx'

export function useApi() {
  return {
    get,
    lay,
    reset,
    set,
    setIf,
    setIfPresent,
    setOmit,
    setPick,
    entries,
    keys,
    stringify,
    values,
    format,
    omit,
    pick,
    executor,
    warden,
    bind,
    validate,
    clearValidate,
    register,
    define: useDefine(),
    getCustomTypes,
    getGlobalCustomTypes,
    getItems,
    getLogs,
    getRules,
  }
}
