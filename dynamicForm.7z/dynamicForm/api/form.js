import { nextTick } from 'vue'

/**
 * 绑定表单实例
 *
 * @param {Object} instance - 要绑定的表单实例对象
 * @returns {Object} 返回代理对象，支持链式调用
 */
export function bind(instance) {
  const { ctx, proxy } = this

  if (!ctx.formInstances.includes(instance))
    ctx.formInstances.push(instance)

  return proxy
}

/**
 * 验证表单数据
 *
 * @param {Function} cb - 回调函数，会在校验结束后被调用，参数为是否验证成功
 * @returns {Promise<boolean>} 是否验证成功
 *
 * @throws {Error} 如果表单实例未绑定则抛出错误
 */
export async function validate(cb) {
  const { ctx } = this

  if (!ctx.formInstances.length)
    throw new Error('form instance has not bind')

  try {
    for (const instance of ctx.formInstances)
      await instance?.validate()

    cb?.(true)
    return true
  }
  catch {
    cb?.(false)
    return false
  }
}

/**
 * 清除表单验证结果
 *
 * @param {string|string[]} [props] - 要清除验证结果的字段名，不传则清除所有字段的验证结果
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @throws {Error} 如果表单实例未绑定则抛出错误
 *
 * @example
 * // 清除所有字段的验证结果
 * formData.clearValidate()
 *
 * // 清除指定字段的验证结果
 * formData.clearValidate('foo')
 *
 * // 清除多个字段的验证结果
 * formData.clearValidate(['foo', 'boo'])
 */
export function clearValidate(props) {
  const { ctx, proxy } = this

  if (!ctx.formInstances.length)
    throw new Error('form instance has not bind')

  const handlers = []

  if (props) {
    const propSet = new Set(Array.isArray(props) ? props : [props])
    for (const instance of ctx.formInstances) {
      const rules = instance?.rules
      if (!rules)
        continue

      const _props = propSet.intersection(new Set(Object.keys(rules)))
      if (_props.size)
        handlers.push(() => instance?.clearValidate?.(Array.from(_props)))
    }
  }
  else {
    for (const instance of ctx.formInstances)
      handlers.push(() => instance?.clearValidate?.())
  }

  // reset.clearValidate 链式调用的使用方式会清除不完全，故使用nextTick
  if (handlers.length)
    nextTick(() => handlers.forEach(handler => handler()))

  return proxy
}
