import { deepClone } from 'lodash'
/**
 * 重置表单数据到初始默认值
 *
 * @returns {Object} 返回代理对象，支持链式调用
 */
export function reset() {
  const { ctx, proxy } = this

  for (const key in ctx.defaultValue)
    proxy.value[key] = ctx.defaultValue[key]

  return proxy
}

/**
 * 从指定对象中选择特定字段并更新到表单数据
 *
 * @param {Object} val - 包含要更新数据的源对象
 * @param {string|string[]} props - 要选择更新的字段名，可以是单个字段名或字段名数组
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @example
 * // 只更新指定的字段
 * formData.setPick({ claimIdCard: '123456789012345678', claimRole: 1 }, 'claimIdCard')
 *
 * // 更新多个指定字段
 * formData.setPick({ claimIdCard: '123456789012345678', claimRole: 1, quantity: 2 }, ['claimIdCard', 'claimRole'])
 */
export function setPick(val, props) {
  const { ctx, proxy } = this

  let entries
  if (Array.isArray(props))
    entries = Object.entries(val).filter(([key]) => props.includes(key))

  else if (typeof props === 'string')
    entries = Object.entries(val).filter(([key]) => key === props)

  else {
    console.warn(`props must be string or array, but got ${typeof props}`)
    return proxy
  }
  entries = entries.filter(([key]) => key in ctx.defaultValue)

  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}

/**
 * 从指定对象中排除特定字段并更新到表单数据
 *
 * @param {Object} val - 包含要更新数据的源对象
 * @param {string|string[]} props - 要排除的字段名，可以是单个字段名或字段名数组
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @example
 * // 更新除 claimIdCard 外的所有字段
 * formData.setOmit({ claimIdCard: '123456789012345678', claimRole: 1 }, 'claimIdCard')
 *
 * // 更新除指定字段外的所有字段
 * formData.setOmit({ claimIdCard: '123456789012345678', claimRole: 1, quantity: 2 }, ['claimIdCard', 'quantity'])
 */
export function setOmit(val, props) {
  const { ctx, proxy } = this

  let entries
  if (Array.isArray(props))
    entries = Object.entries(val).filter(([key]) => !props.includes(key))

  else if (typeof props === 'string')
    entries = Object.entries(val).filter(([key]) => key !== props)

  else {
    console.warn(`props must be string or array, but got ${typeof props}`)
    return proxy
  }
  entries = entries.filter(([key]) => key in ctx.defaultValue)

  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}

/**
 * 只更新源对象中非 undefined 且非 null 的字段到表单数据
 *
 * @param {Object} val - 包含要更新数据的源对象
 * @returns {Object} 返回代理对象，支持链式调用
 */
export function setIfPresent(val) {
  const { ctx, proxy } = this

  const entries = Object.entries(val).filter(([key, value]) => key in ctx.defaultValue && value !== undefined && value !== null)
  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}

/**
 * 根据条件函数更新源对象中的字段到表单数据
 *
 * @param {Object} val - 包含要更新数据的源对象
 * @param {Function} predicate - 条件函数，接收 (value, key) 参数，返回布尔值决定是否更新该字段
 * @returns {Object} 返回代理对象，支持链式调用
 *
 * @description
 * 此函数根据提供的条件函数来决定是否将源对象中的字段更新到表单数据中
 *
 * @example
 * // 只更新值大于 0 的数字字段
 * // 只会更新 quantity 字段
 * formData.setIf({ claimIdCard: '123456789012345678', quantity: 5, monthlyFlag: 0 }, (value, key) => typeof value === 'number' && value > 0)
 */
export function setIf(val, predicate) {
  const { ctx, proxy } = this

  const entries = Object.entries(val).filter(([key, value]) => key in ctx.defaultValue && predicate(value, key))
  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}

export function set(val) {
  const { ctx, proxy } = this

  const entries = Object.entries(val).filter(([key]) => key in ctx.defaultValue)
  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}

export function get(key) {
  const { proxy } = this
  return deepClone(key ? proxy.value[key] : proxy.value)
}

export function lay(val) {
  const { ctx, proxy } = this

  const entries = Object.entries(val).filter(([key]) => key in ctx.defaultValue)
  ctx.silentUpdate = true
  for (const [key, value] of entries)
    proxy.value[key] = value

  return proxy
}
