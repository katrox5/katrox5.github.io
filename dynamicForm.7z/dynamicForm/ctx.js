export function useCtx() {
  return {
    formatters: new Map(),
    formInstances: [],
    formItems: {},
    formRules: {},
    defaultValue: null,
    logs: [],
    silentUpdate: false,
    cleanups: [],
    customTypes: new Map(),
  }
}

export const globalCtx = {
  customTypes: new Map(),
}
