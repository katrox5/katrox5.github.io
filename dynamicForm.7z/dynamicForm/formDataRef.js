import { onScopeDispose, ref } from 'vue'
import { clone, isSpKey } from './util'
import { useApi } from './api'
import { useCtx } from './ctx'

export default function formDataRef(initial) {
  const API = useApi()

  const value = clone(initial)
  const KEYWORDS = new Set(Object.keys(API).concat('value'))

  ;(() => {
    if (!(value instanceof Object) || Array.isArray(value))
      throw new TypeError(`value must be an object: ${value}`)

    const properties = Object.keys(value)
    const intersection = new Set(properties).intersection(KEYWORDS)
    if (intersection.size)
      throw new Error(`value cannot contain reserved keywords: ${Array.from(intersection)}`)
  })()

  const CTX = useCtx()
  CTX.defaultValue = clone(value)

  const formData = ref(value)
  let formDataProxy

  const valueProxy = new Proxy(formData.value, {
    get(target, property, receiver) {
      if (property in API) {
        return API[property].bind({
          ctx: CTX,
          origin: formData,
          proxy: formDataProxy,
        })
      }
      if (isSpKey(property))
        return CTX.formatters.get(property.slice(1)).value

      return Reflect.get(target, property, receiver)
    },
    set(target, property, value, receiver) {
      return Reflect.set(target, property, value, receiver)
    },
  })

  formDataProxy = new Proxy(formData, {
    get(target, property, receiver) {
      if (property in target.value)
        return Reflect.get(target.value, property, receiver)

      if (property === 'value')
        return valueProxy

      if (property in API) {
        return API[property].bind({
          ctx: CTX,
          origin: formData,
          proxy: formDataProxy,
        })
      }

      if (isSpKey(property))
        return CTX.formatters.get(property.slice(1)).value

      return Reflect.get(target, property, receiver)
    },
    set(target, property, value, receiver) {
      if (property in target.value)
        return Reflect.set(target.value, property, value, receiver)

      return Reflect.set(target, property, value, receiver)
    },
  })

  onScopeDispose(() => {
    for (const cleanup of CTX.cleanups)
      cleanup?.()
  })

  return formDataProxy
}
