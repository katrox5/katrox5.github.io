<template>
  <!-- 参考 ./demo.vue 如何配合 formDataRef 高效使用 -->
  <el-form
    ref="formRef"
    v-bind="$attrs"
    :model="formData"
    :rules="formRules"
    :data-uid="randomUUID()"
    label-width="auto"
    class="dynamic-form"
  >
    <div
      class="form-table"
      :style="{
        gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        gridAutoFlow: `${flow}${dense ? ' dense' : ''}`,
      }"
    >
      <template v-for="item in formItems">
        <div
          v-if="(dataKeys.includes(item.prop) || item.slot) && (!('if' in item) || item.if)"
          v-show="!('show' in item) || item.show"
          :key="item.prop ?? item.slot"
          :style="{ gridArea: `span ${item.row ?? 1} / span ${item.col ?? 1}` }"
          :class="{ 'form-item-wrapper': $attrs['label-position'] === 'top' && item.label === '' }"
        >
          <slot v-if="!item.prop && item.label === undefined && item.slot && $slots[item.slot]" :name="item.slot" />
          <el-form-item
            v-else-if="item.prop || item.label !== undefined"
            :prop="item.prop"
            :label="item.label"
            :labelWidth="item.label === undefined ? '0' : undefined"
            class="form-item"
          >
            <template v-if="item.slot && $slots[item.slot]">
              <slot :name="item.slot" />
            </template>
            <template v-else-if="item.type === 'input'">
              <el-input
                :value="item.model ?? formData[item.prop]"
                v-bind="{
                  placeholder: $t(`请输入${item.label ?? ''}`),
                  showWordLimit: item.attrs?.type === 'textarea' && item.attrs?.maxlength ? true : undefined,
                  ...item.attrs,
                }"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
                v-on="item.on"
              >
                <template v-for="(slotName, slot) in item.slots" #[slot]>
                  <slot v-if="slotName && $slots[slotName]" :name="slotName" />
                </template>
              </el-input>
            </template>
            <template v-else-if="item.type === 'select'">
              <Scope
                v-slot="scopeProps"
                :props="{ options: item.options, loadedOptions: item.options.slice(0, 10) }"
                :once="false"
              >
                <el-select
                  v-infinit-scroll="scopeProps"
                  :value="item.model ?? formData[item.prop]"
                  v-bind="{
                    placeholder: $t(`请选择${item.label ?? ''}`),
                    ...item.attrs,
                  }"
                  @input="v => item.model ? item.model = v : formData[item.prop] = v"
                  v-on="item.on"
                >
                  <el-option
                    v-for="option in scopeProps.loadedOptions"
                    :key="option.value"
                    :label="option.label"
                    :value="option.value"
                  />
                  <template v-for="(slotName, slot) in item.slots" #[slot]>
                    <slot v-if="slotName && $slots[slotName]" :name="slotName" />
                  </template>
                </el-select>
              </Scope>
            </template>
            <template v-else-if="item.type === 'radio'">
              <el-radio-group
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
                v-on="item.on"
              >
                <el-radio v-for="option in item.options" :key="option.value" :label="option.value">
                  {{ option.label }}
                </el-radio>
              </el-radio-group>
            </template>
            <template v-else-if="item.type === 'checkbox'">
              <el-checkbox-group
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
                v-on="item.on"
              >
                <el-checkbox
                  v-for="option in item.options"
                  :key="option.value"
                  :label="option.value"
                >
                  {{ option.label }}
                </el-checkbox>
              </el-checkbox-group>
            </template>
            <template v-else-if="item.type === 'cascader'">
              <el-cascader
                :value="item.model ?? formData[item.prop]"
                :options="item.options"
                v-bind="{
                  placeholder: $t(`请选择${item.label ?? ''}`),
                  ...item.attrs,
                }"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
                v-on="item.on"
              >
                <template v-for="(slotName, slot) in item.slots" #[slot]>
                  <slot v-if="slotName && $slots[slotName]" :name="slotName" />
                </template>
              </el-cascader>
            </template>
            <template v-else-if="item.type">
              <component
                :is="item.type"
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
                v-on="item.on"
              />
            </template>
          </el-form-item>
        </div>
      </template>
    </div>
  </el-form>
</template>

<script setup>
import { useVModel, watchOnce } from '@vueuse/core'
import { computed, ref } from 'vue'
import Scope from '../exComp/scope.vue'
import { randomUUID, vInfinitScroll } from './util'

const props = defineProps({
  data: {
    required: true,
  },
  cols: {
    type: Number,
    default: 1,
  },
  flow: {
    type: String,
    default: 'row', // row | column
  },
  dense: {
    type: Boolean,
    default: false,
  },
  name: {
    type: String,
    default: 'default',
  },
})

const emit = defineEmits(['update:data'])

const formData = useVModel(props, 'data', emit)

const formItems = props.data.getItems(props.name)
const formRules = props.data.getRules(props.name)
const dataKeys = computed(() => props.data.keys())

const formRef = ref(null)
watchOnce(formRef, ins => formData.value.bind(ins))
</script>

<style scoped lang="less">
.dynamic-form {
  .form-table {
    display: grid;
    column-gap: 12px;

    .form-item-wrapper:has(.form-item) {
      display: flex;
      flex-direction: column-reverse;
    }

    .form-item {
      position: relative;
    }
  }
  /deep/ .el-textarea .el-input__count {
    line-height: normal;
  }
  .el-select {
    width: 100%;
  }
}
</style>
