<template>
  <el-form
    ref="formRef"
    v-bind="$attrs"
    :model="formData"
    :rules="formRules"
    :data-uid="randomUUID()"
    label-width="auto"
    class="dynamic-form"
  >
    <div
      class="form-table"
      :style="{
        gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        gridAutoFlow: `${flow}${dense ? ' dense' : ''}`,
        columnGap: `${isString(gapX) ? gapX : `${gapX * 0.25}rem`}`,
        rowGap: `${isString(gapY) ? gapY : `${gapY * 0.25}rem`}`,
      }"
    >
      <template v-for="(item, index) in formItems">
        <div
          v-if="(dataKeys.includes(item.prop) || item.slot) && (!('if' in item) || item.if)"
          v-show="!('show' in item) || item.show"
          :key="item.prop ?? `${item.slot}-${index}`"
          :style="{ gridArea: `span ${item.row ?? 1} / span ${item.col ?? 1}` }"
          :class="{ 'form-item-wrapper': $attrs['label-position'] === 'top' }"
        >
          <slot v-if="!item.prop && item.label === none && item.slot && $slots[item.slot]" :name="item.slot" />
          <el-form-item
            v-else-if="item.prop || item.label !== none"
            :prop="item.prop"
            :labelWidth="item.label !== none ? none : '0'"
            class="form-item"
          >
            <template v-if="item.label != null" #label>
              <ReuseTypeSlot :type="item.label" />
            </template>
            <template v-if="item.slot">
              <slot v-if="$slots[item.slot]" :name="item.slot" />
              <template v-else-if="item.slots?.default">
                {{ item.slots.default }}
              </template>
            </template>
            <template v-else-if="item.type === 'input'">
              <el-input
                :value="item.model ?? formData[item.prop]"
                v-bind="{
                  placeholder: `请输入${getPropName(item.label)}`,
                  showWordLimit: item.attrs?.type === 'textarea' && item.attrs?.maxlength ? true : none,
                  ...item.attrs,
                }"
                v-on="item.on"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
              >
                <template v-for="(content, slot) in item.slots" #[slot]>
                  <ReuseTypeSlot :key="slot" :type="content" />
                </template>
              </el-input>
            </template>
            <template v-else-if="item.type === 'select'">
              <Scope
                v-slot="scopeProps"
                :props="{ options: item.options, loadedOptions: item.options.slice(0, 10) }"
                :once="false"
              >
                <el-select
                  v-infinit-scroll="scopeProps"
                  :value="item.model ?? formData[item.prop]"
                  v-bind="{
                    placeholder: `请选择${getPropName(item.label)}`,
                    ...item.attrs,
                  }"
                  v-on="item.on"
                  @input="v => item.model ? item.model = v : formData[item.prop] = v"
                >
                  <el-option
                    v-for="option in scopeProps.loadedOptions"
                    :key="option.value"
                    :label="option.label"
                    :value="option.value"
                  />
                  <template v-for="(content, slot) in item.slots" #[slot]>
                    <ReuseTypeSlot :key="slot" :type="content" />
                  </template>
                </el-select>
              </Scope>
            </template>
            <template v-else-if="item.type === 'radio'">
              <el-radio-group
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                v-on="item.on"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
              >
                <el-radio v-for="option in item.options" :key="option.value" :label="option.value">
                  {{ option.label }}
                </el-radio>
              </el-radio-group>
            </template>
            <template v-else-if="item.type === 'checkbox'">
              <el-checkbox-group
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                v-on="item.on"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
              >
                <el-checkbox
                  v-for="option in item.options"
                  :key="option.value"
                  :label="option.value"
                >
                  {{ option.label }}
                </el-checkbox>
              </el-checkbox-group>
            </template>
            <template v-else-if="item.type === 'cascader'">
              <el-cascader
                :value="item.model ?? formData[item.prop]"
                :options="item.options"
                v-bind="{
                  placeholder: `请选择${getPropName(item.label)}`,
                  ...item.attrs,
                }"
                v-on="item.on"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
              >
                <template v-for="(content, slot) in item.slots" #[slot]>
                  <ReuseTypeSlot :key="slot" :type="content" />
                </template>
              </el-cascader>
            </template>
            <template v-else-if="item.type">
              <component
                :is="isComponent(item.type) ? item.type : getCustomType(item.type)"
                :value="item.model ?? formData[item.prop]"
                v-bind="item.attrs"
                v-on="item.on"
                @input="v => item.model ? item.model = v : formData[item.prop] = v"
              >
                <template v-for="(content, slot) in item.slots" #[slot]>
                  <ReuseTypeSlot :key="slot" :type="content" />
                </template>
              </component>
            </template>
          </el-form-item>
        </div>
      </template>
    </div>
    <DefineTypeSlot v-slot="{ type }">
      <component :is="type" v-if="isComponent(type)" />
      <span v-else-if="isXml(type)" v-html="type" />
      <slot v-else-if="type && $slots[type]" :name="type" />
      <template v-else>
        {{ type }}
      </template>
    </DefineTypeSlot>
  </el-form>
</template>

<script setup>
import { useVModel, watchOnce } from '@vueuse/core'
import { ref } from 'vue'
import Scope from '../exComp/scope.vue'
import createReusableTemplate from '../exComp/createReusableTemplate'
import { isComponent, isStr, isXml, randomUUID, vInfinitScroll } from './util'

const props = defineProps({
  value: {
    required: true,
  },
  cols: {
    type: Number,
    default: 1,
  },
  flow: {
    type: String,
    default: 'row', // row | column
  },
  dense: {
    type: Boolean,
    default: false,
  },
  name: {
    type: String,
    default: 'default',
  },
  gapX: {
    type: [Number, String],
    default: 0,
  },
  gapY: {
    type: [Number, String],
    default: 0,
  },
})

const emit = defineEmits(['update:value'])

const [DefineTypeSlot, ReuseTypeSlot] = createReusableTemplate()

const isString = isStr // 模板中无法直接使用? (vue的神秘bug增加了)

const none = undefined

const formData = useVModel(props, 'value', emit)

const formRef = ref(null)

const formItems = formData.value.getItems(props.name)
const formRules = formData.value.getRules(props.name)
const dataKeys = formData.value.keys()

const customTypes = formData.value.getCustomTypes()
const globalCustomTypes = formData.value.getGlobalCustomTypes()

const getCustomType = type => customTypes.get(type) ?? globalCustomTypes.get(type)

const getPropName = label => !isComponent(label) && !isXml(label) && isStr(label) ? label : ''

watchOnce(formRef, ins => formData.value.bind(ins))
</script>

<style scoped lang="less">
.dynamic-form {
  .form-table {
    display: grid;
    column-gap: 12px;

    .form-item-wrapper:has(.form-item) {
      display: flex;
      flex-direction: column-reverse;
    }

    .form-item {
      position: relative;
    }
  }
  /deep/ .el-textarea .el-input__count {
    line-height: normal;
  }
  .el-select {
    width: 100%;
  }
}
</style>
