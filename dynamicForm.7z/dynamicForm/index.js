import { defineComponent } from 'vue'
import DynamicForm from './dynamicForm.vue'
import formDataRef from './formDataRef'
import { useInvoker, useListener } from './api/eventBus'
import { globalCtx } from './ctx'
import { reservedTypes } from './util'

function useDynamicForm(initial) {
  const value = formDataRef(initial)
  return {
    formData: value,
    DynamicForm: defineComponent({
      extends: DynamicForm,
      props: {
        value: {
          default: () => value,
        },
      },
    }),
  }
}

const globalConfig = {
  register(component, key) {
    if (reservedTypes.includes(key))
      throw new Error(`can not use "${key}" as key`)

    globalCtx.customTypes.set(key, component)
  },
}

export {
  DynamicForm,
  formDataRef,
  useDynamicForm,
  useInvoker,
  useListener,
  globalConfig,
}
