import { computed, defineComponent, h } from 'vue'
import DynamicForm from './dynamicForm.vue'
import formDataRef from './formDataRef'
import { useInvoker } from './api/eventBus'

function useDynamicForm(initial) {
  const data = formDataRef(initial)
  return {
    formData: data,
    DynamicForm: defineComponent({
      name: 'DynamicForm',
      setup(_, { attrs, slots }) {
        const vnodes = computed(() =>
          Object.keys(slots).map(slot =>
            h('template', { slot }, slots[slot]?.()),
          ),
        )

        const props = computed(() => ({
          data,
          ...Object.fromEntries(
            Object.entries(attrs).filter(([prop]) =>
              ['cols', 'flow', 'dense', 'name'].includes(prop),
            ),
          ),
        }))

        const restAttrs = computed(() => ({
          ...Object.fromEntries(
            Object.entries(attrs).filter(([attr]) =>
              !['data', 'cols', 'flow', 'dense', 'name'].includes(attr),
            ),
          ),
        }))
        return () => h(DynamicForm, { props: props.value, attrs: restAttrs.value }, vnodes.value)
      },
    }),
  }
}

export {
  DynamicForm,
  formDataRef,
  useDynamicForm,
  useInvoker,
}
