<template>
  <div style="margin-left: 16px">
    <el-button type="primary" size="small" @click="dialogVisible = true">
      Demo
    </el-button>
    <el-dialog
      :visible="dialogVisible"
      title="理赔申请表单"
      width="1200px"
      @close="dialogVisible = false"
    >
      <DemoForm label-position="top" :cols="4">
        <template #claimIdCard4>
          <span style="color: lightskyblue">身份证后4位：{{ claimFormData.$claimIdCard }}</span>
        </template>
        <template #text>
          <span>{{ claimFormData.stringify() }}</span>
          <div>
            {{ claimFormData.pick(['claimIdCard', 'claimRole']) }}
          </div>
        </template>
      </DemoForm>
      <DynamicForm :data="departmentData" :cols="2" name="part2" />
      <DynamicForm :data="departmentData" :cols="2" name="part1" />
      <template #footer>
        <el-button @click="onToggleValidation">
          切换验证状态
        </el-button>
        <el-button @click="handleReset">
          重置
        </el-button>
        <el-button type="primary" @click="handlePrint">
          打印
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { DynamicForm, formDataRef, useDynamicForm, useInvoker } from 'src/components/dynamicForm'
import { useEventBus } from '@vueuse/core'

const isValidationRequired = ref(true)

const { DynamicForm: DemoForm, formData: claimFormData } = useDynamicForm({
  claimIdCard: null,
  claimRole: undefined,
  monthlyFlag: undefined,
  remark: null,
  claimQuantity: '1',
  unit: null,
  claimPayItems: [],
})

claimFormData
  .format('claimIdCard', val => val && val.slice(-4))
  .format('claimQuantity', Number)
  .warden('claimNotificationBus', {
    debounce: 500,
    props: ['claimIdCard', 'claimRole'],
    downstream: val => val.join('-'),
  })
  .executor('claimExecutor', ({ fn, event }) => {
    console.log(event)
  })
  .define(() => ({
    claimIdCard: {
      label: '客户身份证号',
      type: 'input',
      if: claimFormData.claimRole === 18,
      col: 2,
      validator(val) {
        if (val?.length !== 18) return '请输入18位身份证号'
      },
      slots: {
        append: 'claimIdCard4',
      },
      attrs: {
        maxlength: isValidationRequired.value ? 5 : 10,
      },
    },
    claimRole: {
      label: '理赔角色',
      type: 'select',
      show: claimFormData.$claimQuantity,
      options: (() => {
        const items = []
        for (let i = 0; i < 100; i++) {
          items.push({ label: `角色${i}`, value: i })
        }
        return items
      })(),
      on: {
        change(val) {
          console.log('角色变更', val)
        },
      },
      attrs: {
        disabled: claimFormData.claimIdCard?.length === 9,
      },
    },
    claimQuantity: {
      label: '损失数量',
      type: 'input',
      // 等同于 on.change
      $change(val) {
        console.log('数量变更', val)
      },
    },
    unit: {
      label: '',
      type: 'select',
      options: [
        { label: '个', value: 1 },
        { label: '斤', value: 2 },
        { label: '公斤', value: 3 },
        { label: '盒', value: 4 },
        { label: '包', value: 5 },
      ],
      attrs: {
        placeholder: '请选择损失单位',
      },
      $change: (val) => {
        console.log('单位变更0', val)
      },
      on: {
        change: [
          (val) => {
            console.log('单位变更1', val)
          },
          (val) => {
            console.log('单位变更2', val)
          },
        ],
      },
    },
    remark: {
      label: '理赔备注',
      type: 'input',
      row: 2,
      attrs: {
        type: 'textarea',
        maxlength: 500,
        autosize: { minRows: 3, maxRows: 5 },
      },
      required: isValidationRequired.value,
    },
    monthlyFlag: {
      label: '是否月结',
      type: 'radio',
      col: 2,
      options: [
        { label: '是', value: 1 },
        { label: '否', value: 0 },
        { label: '待定', value: 2 },
      ],
    },
    // 插槽语法
    $claimIdCard4: {
      label: '',
    },
    claimPayItems: {
      label: '理赔款项',
      type: 'checkbox',
      col: 2,
      options: [
        { label: '理赔款', value: '1' },
        { label: '运费', value: '2' },
        { label: '安抚（电子券）', value: '3' },
        { label: '其他费用', value: '4' },
      ],
    },
    $blankSlot: {},
    $text: {},
  }), { defaultRequired: true })

const departmentData = formDataRef({
  departmentName: undefined,
  departmentCode: null,
  departmentCount: 0,
  departmentDesc: '',
})
  .define(() => ({
    departmentName: {
      label: '部门名称',
      type: 'input',
    },
    departmentDesc: {
      label: '部门描述',
      type: 'input',
      attrs: {
        type: 'textarea',
      },
      required: false,
    },
  }), { formName: 'part1' })
  .define(() => ({
    departmentCode: {
      label: '部门编码',
      type: 'input',
      required: false,
    },
    departmentCount: {
      label: '部门人数',
      type: 'input',
      attrs: {
        type: 'number',
      },
    },
  }), { formName: 'part2' })

const dialogVisible = ref(false)

const handleReset = () => {
  claimFormData.reset().clearValidate()
  departmentData.reset().clearValidate()
}

const handlePrint = async () => {
  const isValid = await claimFormData.validate()
  console.log({ isValid })
  if (isValid) {
    console.log({ ...claimFormData.value })
  }
  const logs = claimFormData.getLogs()
  for (const log of logs)
    log.event.trace()
  console.log(logs)
}

const invoke = useInvoker('claimExecutor')

const onToggleValidation = async () => {
  isValidationRequired.value = !isValidationRequired.value
  const val = await invoke('validate')
  claimFormData.set({
    claimIdCard: '123456789',
  })
  claimFormData.lay({
    claimRole: 18,
  })
  console.log('校验结果', val)
}

const bus = useEventBus('claimNotificationBus')
bus.on((data) => {
  console.log('理赔通知总线', data)
})
</script>
