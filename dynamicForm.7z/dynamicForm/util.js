import { effectScope } from 'vue'
import { useInfiniteScroll } from '@vueuse/core'
import dayjs from 'dayjs'

export const vInfinitScroll = {
  bind(el, binding) {
    if (binding.value.options.length <= 10) {
      return
    }
    const scope = effectScope()
    scope.run(() => {
      useInfiniteScroll(
        el.querySelector('.el-select-dropdown .el-select-dropdown__wrap'),
        () => {
          const index = binding.value.loadedOptions.length
          if (index === binding.value.options.length) {
            scope.stop()
          }
          else {
            binding.value.loadedOptions.push(...binding.value.options.slice(index, index + 10))
          }
        },
        { distance: 10 },
      )
    })
  },
}

export function randomUUID() {
  return crypto.randomUUID?.() ?? 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

export function debounceFilter(ms, options = {}) {
  let timer
  let maxTimer
  let lastRejector
  let lastCallTime = 0

  const _clearTimeout = (timer) => {
    clearTimeout(timer)
    lastRejector?.()
    lastRejector = undefined
  }

  let lastInvoker

  const filter = (invoke) => {
    const duration = ms
    const maxDuration = options.maxWait
    const currentTime = Date.now()

    let firstCall = false
    if (lastCallTime === 0 || (currentTime - lastCallTime >= duration))
      firstCall = true

    lastCallTime = currentTime
    if (firstCall) {
      if (timer)
        _clearTimeout(timer)
      if (maxTimer)
        _clearTimeout(maxTimer)
      return Promise.resolve(invoke())
    }

    if (timer)
      _clearTimeout(timer)

    if (duration <= 0 || (maxDuration !== undefined && maxDuration <= 0)) {
      if (maxTimer) {
        _clearTimeout(maxTimer)
        maxTimer = undefined
      }
      return Promise.resolve(invoke())
    }

    return new Promise((resolve, reject) => {
      lastRejector = options.rejectOnCancel ? reject : resolve
      lastInvoker = invoke
      // Create the maxTimer. Clears the regular timer on invoke
      if (maxDuration && !maxTimer) {
        maxTimer = setTimeout(() => {
          if (timer)
            _clearTimeout(timer)
          maxTimer = undefined
          resolve(lastInvoker())
        }, maxDuration)
      }

      // Create the regular timer. Clears the max timer on invoke
      timer = setTimeout(() => {
        if (maxTimer)
          _clearTimeout(maxTimer)
        maxTimer = undefined
        resolve(invoke())
      }, duration)
    })
  }

  return filter
}

export function now() {
  return dayjs().format('YYYY-MM-DD HH:mm:ss')
}

export const isDev = globalThis?.g?.env === 'dev'
