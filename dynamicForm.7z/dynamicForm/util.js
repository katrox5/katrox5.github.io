import { effectScope } from 'vue'
import { useEventBus, useInfiniteScroll } from '@vueuse/core'
import dayjs from 'dayjs'

export const vInfinitScroll = {
  bind(el, binding) {
    if (binding.value.options.length <= 10) {
      return
    }
    const scope = effectScope()
    scope.run(() => {
      useInfiniteScroll(
        el.querySelector('.el-select-dropdown .el-select-dropdown__wrap'),
        () => {
          const index = binding.value.loadedOptions.length
          if (index === binding.value.options.length) {
            scope.stop()
          }
          else {
            binding.value.loadedOptions.push(...binding.value.options.slice(index, index + 10))
          }
        },
        { distance: 10 },
      )
    })
  },
}

export function randomUUID() {
  return crypto.randomUUID?.() ?? 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

export function debounceFilter(ms, options = {}) {
  let timer
  let maxTimer
  let lastRejector
  let lastCallTime = 0

  const _clearTimeout = (timer) => {
    clearTimeout(timer)
    lastRejector?.()
    lastRejector = undefined
  }

  let lastInvoker

  const filter = (invoke) => {
    const duration = ms
    const maxDuration = options.maxWait
    const currentTime = Date.now()

    let firstCall = false
    if (lastCallTime === 0 || (currentTime - lastCallTime >= duration))
      firstCall = true

    lastCallTime = currentTime
    if (firstCall) {
      if (timer)
        _clearTimeout(timer)
      if (maxTimer)
        _clearTimeout(maxTimer)
      return Promise.resolve(invoke())
    }

    if (timer)
      _clearTimeout(timer)

    if (duration <= 0 || (maxDuration !== undefined && maxDuration <= 0)) {
      if (maxTimer) {
        _clearTimeout(maxTimer)
        maxTimer = undefined
      }
      return Promise.resolve(invoke())
    }

    return new Promise((resolve, reject) => {
      lastRejector = options.rejectOnCancel ? reject : resolve
      lastInvoker = invoke
      // Create the maxTimer. Clears the regular timer on invoke
      if (maxDuration && !maxTimer) {
        maxTimer = setTimeout(() => {
          if (timer)
            _clearTimeout(timer)
          maxTimer = undefined
          resolve(lastInvoker())
        }, maxDuration)
      }

      // Create the regular timer. Clears the max timer on invoke
      timer = setTimeout(() => {
        if (maxTimer)
          _clearTimeout(maxTimer)
        maxTimer = undefined
        resolve(invoke())
      }, duration)
    })
  }

  return filter
}

export function now() {
  return dayjs().format('YYYY-MM-DD HH:mm:ss')
}

export function clone(obj) {
  if (obj === null || typeof obj !== 'object')
    return obj

  if (obj instanceof Date)
    return new Date(obj)
  if (Array.isArray(obj))
    return obj.map(item => clone(item))

  const cloned = {}
  for (const key in obj)
    cloned[key] = clone(obj[key])

  return cloned
}

export function createBus(key) {
  const { promise: created, resolve } = Promise.withResolvers()
  let _on, _off, _emit
  let size = 0
  // 异步嵌套使得 useEventBus 无法获取 currentScope，否则清理函数的执行会导致异常现象
  setTimeout(() => {
    const bus = useEventBus(key)
    _on = bus.on
    _off = bus.off
    _emit = bus.emit
    resolve()
  })
  const on = (...args) => {
    size++
    let unsubscribe
    created.then(() => unsubscribe = _on(...args))
    return () => {
      unsubscribe?.()
      size--
    }
  }
  const off = (...args) => {
    created.then(() => {
      _off(...args)
      size--
    })
  }
  const emit = (...args) => {
    created.then(_emit.bind(null, ...args))
  }
  return {
    on,
    off,
    emit,
    get size() {
      return size
    },
  }
}

export const isDev = globalThis?.g?.env === 'dev'

export class ExMap extends Map {
  computeIfAbsent(key, def) {
    let val
    if (this.has(key))
      val = this.get(key)
    else {
      val = def instanceof Function ? def() : def
      this.set(key, val)
    }
    return val
  }
}

export function multiPromise(total) {
  const proms = Array.from({ length: total }, Promise.withResolvers)
  let index = 0

  const resolve = (val) => {
    if (index < total)
      proms[index++].resolve(val)
  }

  const reject = (err) => {
    if (index < total)
      proms[index++].reject(err)
  }

  return {
    promises: proms.map(({ promise }) => promise),
    resolve,
    reject,
  }
}

export function isSpKey(val) {
  return isStr(val) && val.startsWith('$')
}

export const reservedTypes = Object.freeze(['input', 'select', 'radio', 'checkbox', 'cascader'])

export function isStr(val) {
  return typeof val === 'string'
}

export function isXml(val) {
  return isStr(val) && val.startsWith('<') && val.endsWith('>')
}

export function isComponent(val) {
  return val instanceof Object
}
