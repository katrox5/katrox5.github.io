import Vue from 'vue'
import ConfirmDialog from './index.vue'

const ConfirmDialogConstructor = Vue.extend(ConfirmDialog)
let instance

export default function $confirmDialog(options = {}) {
  instance ??= new ConfirmDialogConstructor()

  document.body.appendChild(instance.$mount().$el)
  return instance?.show(options)
}
