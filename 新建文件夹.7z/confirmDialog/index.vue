<template>
  <el-dialog
    :visible="isRevealed"
    :show-close="false"
    :close-on-click-modal="false"
    class="confirm-dialog"
    top="50vh"
    width="400px"
    center
  >
    <span v-if="typeof content === 'string'">
      {{ content }}
    </span>
    <component
      :is="content"
      v-else-if="typeof content === 'object' && 'render' in content"
    />
    <template #footer>
      <el-button v-bind="cancelButtonAttrs" @click="cancel">
        {{ cancelButtonText }}
      </el-button>
      <el-button
        v-bind="{
          type: 'primary',
          ...confirmButtonAttrs,
        }"
        @click="confirm"
      >
        {{ confirmButtonText }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { useConfirmDialog } from '@vueuse/core'
import { ref } from 'vue'

defineExpose({
  show({
    content: _content,
    confirmButtonText: _confirmButtonText = '确定',
    cancelButtonText: _cancelButtonText = '取消',
    confirmButtonAttrs: _confirmButtonAttrs = {},
    cancelButtonAttrs: _cancelButtonAttrs = {},
  }) {
    _content && (content.value = _content)
    _confirmButtonText && (confirmButtonText.value = _confirmButtonText)
    _cancelButtonText && (cancelButtonText.value = _cancelButtonText)
    _confirmButtonAttrs && (confirmButtonAttrs.value = _confirmButtonAttrs)
    _cancelButtonAttrs && (cancelButtonAttrs.value = _cancelButtonAttrs)
    return reveal()
  },
})

const content = ref('')
const confirmButtonText = ref('')
const cancelButtonText = ref('')

const confirmButtonAttrs = ref({})
const cancelButtonAttrs = ref({})

const { isRevealed, reveal, confirm, cancel } = useConfirmDialog()
</script>

<style lang="less" scoped>
.confirm-dialog {
  /deep/ .el-dialog {
    transform: translateY(-50%);
  }
  /deep/ .el-dialog__header {
    display: none;
  }
}
</style>
