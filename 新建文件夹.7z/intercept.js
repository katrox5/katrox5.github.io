const set = new WeakSet()

const vIntercept = {
  bind(el, binding, vnode) {
    if (binding.arg === 'disabled') return
    if (!Object.keys(binding.modifiers).length) return

    const handler = async (event) => {
      if (set.has(event)) return

      event.preventDefault()
      event.stopPropagation()

      let flag
      if (binding.value instanceof Function) {
        const echo = binding.value()
        flag = echo instanceof Promise ? await echo : echo
      }
      else {
        flag = Boolean(binding.value)
      }
      if (!flag) {
        const newEvent = new event.constructor(event.type, event)
        set.add(newEvent)
        el.dispatchEvent(newEvent)
      }
    }

    for (const mod in binding.modifiers) {
      el.addEventListener(mod, handler, true)
    }
    vnode.interceptHandler = handler
  },
  unbind(el, binding, vnode) {
    if (vnode.interceptHandler) {
      for (const mod in binding.modifiers) {
        el.removeEventListener(mod, vnode.interceptHandler, true)
      }
    }
  },
}

export default vIntercept
