import { computed, reactive, triggerRef } from 'vue'
import { tryOnBeforeUnmount, useElementBounding, useElementByPoint, useEventListener, useMagicKeys, useMouse, watchPausable, whenever } from '@vueuse/core'
import { Message } from 'element-ui'

/* eslint-disable no-console */
/**
 * 打印从当前组件到根组件的层级结构
 * @param vm 当前组件实例
 * @example
 * 选项式: `printComponentHierarchy(this)`
 * 组合式: `printComponentHierarchy(getCurrentInstance())`
 */
export function printComponentHierarchy(vm) {
  // 仅在开发环境可用
  if (globalThis?.g?.env !== 'dev') return

  let current = vm.proxy ?? vm
  const hierarchy = []
  const hierarchyDetail = []

  while (current) {
    let name = current.$options?.name || current.$options?._componentTag
              || current.$options?.__name || current?.$options?._Ctor?.[0]?.extendOptions?.name
    const filepath = current?.$options?._Ctor?.[0]?.extendOptions?.__file
    if (filepath && (name === 'index' || !name)) {
      name = filepath.endsWith('index.vue') ? filepath.split('/').at(-2) : filepath.split('/').pop().replace('.vue', '')
    }
    if (name) hierarchy.push(name)
    else if (current?.$el) hierarchy.push(current.$el.tagName.toLowerCase())
    if (filepath) hierarchyDetail.push(filepath)
    if (name === 'App') break
    current = current.$parent
  }

  console.group(hierarchy.reverse().join(' > '))
  const itemStyle = 'line-height: 20px; border: 1px solid #ccc; padding: 2px 4px; margin: 2px 2px; display: inline-block; font-weight: normal;'
  const separatorStyle = 'background: transparent; border: none; font-weight: bold;'
  console.log(
    `%c${hierarchyDetail.reverse().join('%c > %c')}`,
    ...Array.from({ length: (hierarchyDetail.length - 1) * 2 }, (_, i) => i % 2 ? separatorStyle : itemStyle).concat(itemStyle),
  )
  console.groupEnd()
}

/**
 * 启用组件追溯模式，使用快捷键：
 * - `Shift+E` 打开调试模式
 * - `Shift+Q` 关闭调试模式
 * - `Shift+C` 输出当前组件信息
 * - `Shift+V` 输出当前组件层级结构
 *
 * **注意：请在vue组件中调用，否则会导致清理函数无法正常执行**
 */
export function traceComponent() {
  // 仅在开发环境可用
  if (globalThis?.g?.env !== 'dev') return

  const { x, y } = useMouse({ type: 'client' })
  const { element } = useElementByPoint({ x, y })
  const bounding = reactive(useElementBounding(element))

  useEventListener('scroll', bounding.update, { passive: true, capture: true })

  const vMapper = {}
  const elements = {}
  const watchers = {}
  let curVAttrs = []
  let isActive = false
  const { shift_c, shift_e, shift_q, shift_v } = useMagicKeys()

  const boxStyle = {
    position: 'fixed',
    pointerEvents: 'none',
    zIndex: 9999,
    backgroundColor: '#3eaf7c44',
    transition: 'all 0.05s linear',
    whiteSpace: 'nowrap',
    color: 'green',
    fontWeight: 'bold',
    display: 'none',
  }

  elements.boxElement = document.createElement('div')
  setStyle4Element(elements.boxElement, boxStyle)

  Object.values(elements).forEach(el => document.body.appendChild(el))

  const boxDynamicStyle = computed(() => {
    if (element.value) {
      return {
        display: 'block',
        width: `${bounding.width}px`,
        height: `${bounding.height}px`,
        left: `${bounding.left}px`,
        top: `${bounding.top}px`,
      }
    }
    return {
      display: 'none',
    }
  })

  watchers.boxStyleWatcher = {
    ...watchPausable(boxDynamicStyle, (newStyle) => {
      setStyle4Element(elements.boxElement, newStyle)
    }, { deep: true }),
  }
  watchers.instanceWatcher = {
    ...watchPausable(element, (el) => {
      if (!el?.dataset) return
      // 通过唯一哈希反向查找组件实例
      const dataVAttr = Object.keys(el.dataset).filter(i => i.startsWith('v-')).map(i => i.replace('v-', ''))
      curVAttrs = dataVAttr
      for (const hash of dataVAttr) {
        if (vMapper[hash]) continue
        const match = globalThis.__VUE_HOT_MAP__?.[hash]
        const filepath = match?.options?.__file || match?.Ctor?.extendOptions?.__file
        Object.assign(vMapper, { [hash]: filepath })
      }
      elements.boxElement.innerText = curVAttrs.join(', ')
    }),
  }
  // 初始为停用状态
  Object.values(watchers).forEach(watcher => watcher?.pause())

  // 打印当前hover组件的信息
  whenever(shift_c, () => {
    if (!isActive) return
    if (!curVAttrs.length) return
    console.group(curVAttrs.join(', '))
    curVAttrs.forEach(vAttr => console.log(vMapper[vAttr]))
    console.groupEnd()
  })
  // 打印当前hover组件的层级结构
  whenever(shift_v, () => {
    if (!isActive) return
    if (!curVAttrs.length) return
    curVAttrs.forEach(vAttr => printComponentHierarchy(globalThis.__VUE_HOT_MAP__?.[vAttr]?.instances?.[0]))
  })
  // 退出组件追溯模式
  whenever(shift_q, () => {
    if (!isActive) return
    Object.values(watchers).forEach(watcher => watcher?.pause())
    Object.values(elements).forEach(el => document.body.removeChild(el))
    isActive = false
    Message.info({
      message: '已退出组件追溯模式，按 Shift+E 重新启用',
      duration: 2000,
    })
  })
  // 启动组件追溯模式
  whenever(shift_e, () => {
    if (isActive) return
    Object.values(watchers).forEach(watcher => watcher?.resume())
    Object.values(elements).forEach(el => document.body.appendChild(el))
    triggerRef(element)
    isActive = true
    Message.success({
      message: '已进入组件追溯模式，按 Shift+Q 退出',
      duration: 2000,
    })
  })

  tryOnBeforeUnmount(() => Object.values(elements).forEach(el => el?.remove()))
}

function setStyle4Element(el, styleObj) {
  for (const property in styleObj) {
    el.style[property] = styleObj[property]
  }
}
