<template>
  <el-form ref="formRef" :model="formData" :rules="rules" class="dynamic-form">
    <el-row :gutter="12">
      <div v-for="item in items" :key="item.prop">
        <el-col v-if="dataKeys.includes(item.prop) || item.slot" :span="(item.span || 1) * 24">
          <el-form-item :label="item.label" :prop="item.prop" :label-width="setIfPresent(item.label, `${labelWidth}px`)">
            <template v-if="item.slot && $slots[item.slot]">
              <slot :name="item.slot" />
            </template>
            <template v-else-if="item.type === 'input'">
              <el-input
                v-model="formData[item.prop]"
                v-bind="{
                  placeholder: $t(`请输入${item.label ?? ''}`),
                  showWordLimit: setIfPresent(item.attrs?.type === 'textarea' && item.attrs?.maxlength, true),
                  ...item.attrs,
                }"
                :class="{ textarea: item.attrs?.type === 'textarea' }"
              />
            </template>
            <template v-else-if="item.type === 'select'">
              <Scope v-slot="scopeProps" :props="{ options: item.options, loadedOptions: item.options.slice(0, 10) }">
                <el-select
                  v-model="formData[item.prop]"
                  v-bind="{
                    placeholder: $t(`请选择${item.label ?? ''}`),
                    ...item.attrs,
                  }"
                  v-infinit-scroll="scopeProps"
                >
                  <el-option
                    v-for="option in scopeProps.loadedOptions"
                    :key="option.value"
                    :label="option.label"
                    :value="option.value"
                  />
                </el-select>
              </Scope>
            </template>
            <template v-else-if="item.type === 'radio'">
              <el-radio-group v-model="formData[item.prop]" v-bind="item.attrs">
                <el-radio
                  v-for="option in item.options"
                  :key="option.value"
                  :label="option.value"
                >
                  {{ option.label }}
                </el-radio>
              </el-radio-group>
            </template>
            <template v-else-if="item.type === 'checkbox'">
              <el-checkbox-group v-model="formData[item.prop]" v-bind="item.attrs">
                <el-checkbox
                  v-for="option in item.options"
                  :key="option.value"
                  :label="option.value"
                >
                  {{ option.label }}
                </el-checkbox>
              </el-checkbox-group>
            </template>
          </el-form-item>
        </el-col>
      </div>
    </el-row>
  </el-form>
</template>

<script setup>
import { useInfiniteScroll, useVModel } from '@vueuse/core'
import { computed, effectScope, ref } from 'vue'
import Scope from './scope.vue'

const props = defineProps({
  data: {
    required: true,
  },
  rules: {
    required: true,
  },
  items: {
    required: true,
  },
})

const emit = defineEmits(['update:data'])

defineExpose({ validate })

const formData = useVModel(props, 'data', emit)

const vInfinitScroll = {
  bind(el, binding) {
    if (binding.value.options.length <= 10) {
      return
    }
    const scope = effectScope()
    scope.run(() => {
      useInfiniteScroll(
        el.querySelector('.el-select-dropdown .el-select-dropdown__wrap'),
        () => {
          const index = binding.value.loadedOptions.length
          if (index === binding.value.options.length) {
            scope.stop()
          }
          else {
            binding.value.loadedOptions.push(...binding.value.options.slice(index, index + 10))
          }
        },
        { distance: 10 },
      )
    })
  },
}

const labelWidth = props.items.reduce((maxWidth, item) => {
  if (item.label) {
    return Math.max(maxWidth, item.label.length * 14)
  }
  return maxWidth
}, 0) + 12 + 6 + 4

const formRef = ref(null)

const dataKeys = computed(() => props.data.keys())

function setIfPresent(predicate, value) {
  return predicate ? value : undefined
}

async function validate() {
  try {
    await formRef.value?.validate()
    return true
  }
  catch {
    return false
  }
}
</script>

<style lang="less">
.dynamic-form {
  .textarea {
    .el-input__count {
      line-height: normal;
    }
  }
}
</style>
