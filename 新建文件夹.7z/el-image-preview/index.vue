<template>
  <el-image
    v-if="imgUrlList.length"
    ref="imgRef"
    :preview-src-list="previewSrcList"
    :src="previewSrcList[0]"
    style="display: none"
  />
</template>

<script setup>
import { computed, ref } from 'vue'

const props = defineProps(['imgUrlList'])

defineExpose({ preview })

const imgRef = ref(null)

const currentImgUrl = ref()

const previewSrcList = computed(() => {
  const arr = props.imgUrlList
  const item = currentImgUrl.value
  return [...arr.slice(arr.indexOf(item)), ...arr.slice(0, arr.indexOf(item))]
})

function preview(url) {
  currentImgUrl.value = url
  imgRef.value?.clickHandler()
}
</script>
