import Vue from 'vue'
import ElImagePreview from './index.vue'

const ElImagePreviewConstructor = Vue.extend(ElImagePreview)

export default function useImagePreivew(imgUrlList) {
  let _preview = null
  let _destroy = null

  setTimeout(() => {
    const instance = new ElImagePreviewConstructor({
      propsData: {
        imgUrlList,
      },
    })

    document.body.appendChild(instance.$mount().$el)

    _preview = instance.preview
    _destroy = () => {
      document.body.removeChild(instance.$el)
      instance.$destroy()
    }
  })

  return {
    preview: (...params) => _preview?.(...params),
    destroy: () => _destroy?.(),
  }
}
