<template>
  <div>
    <slot v-bind="propsRef" />
  </div>
</template>

<script setup>
import { reactive } from 'vue'

const props = defineProps({
  props: {
    type: Object,
    default: () => ({}),
  },
})

const propsRef = reactive(props.props)
</script>
