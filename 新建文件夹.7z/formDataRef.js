import { ref } from 'vue'

/**
 * reset 重置为初始值
 * setOmit 剔除指定属性设置
 * setPick 选取指定属性设置
 * setIfPresent 只设置非空属性，值为undefined或null时略过
 * setIf 只在属性满足指定条件时设置
 * format 为指定属性设置格式器，使用 [$属性名] 访问格式化结果
 * keys 返回属性名数组，受设置的group影响
 * values 返回属性值数组，受设置的group影响
 * entries 返回属性名和属性值元组的数组，受设置的group影响
 * group 条件为真时只返回指定属性
 *
 * @param {Object} defaultValue 简单的JSON对象，属性名不能包含value及以上函数名
 * @param {Object} customFunc 自定义函数，属性名为函数名，函数的首个参数为代理本身，后续参数则为传参
 */
export default function formDataRef(defaultValue, customFunc) {
  const _defaultValue = { ...defaultValue }

  const FORMATTERS = new Map()
  const PROPERTIES = new Set()
  const GROUPS = new Map()

  function isFormatterKey(key) {
    return typeof key === 'string' && key.startsWith('$') && FORMATTERS.has(key.slice(1))
  }

  const FUNC = {
    // this: formData<ref>
    // 1st arg: formDataProxy

    // 重置为初始值
    reset(proxy) {
      for (const key in _defaultValue) {
        proxy[key] = _defaultValue[key]
      }
    },
    /**
     * 剔除指定属性设置(其他不存在于formData的属性同样会被忽略)
     * @param {Object} val 需要更新的数据
     * @param {String | Array<String>} omitProperties 需要剔除的属性
     */
    setOmit(proxy, val, omitProperties) {
      let entries
      if (Array.isArray(omitProperties)) {
        entries = Object.entries(val).filter(([key]) => !omitProperties.includes(key))
      }
      else if (typeof omitProperties === 'string') {
        entries = Object.entries(val).filter(([key]) => key !== omitProperties)
      }
      else {
        throw new TypeError('OmitProperties param must be string or array')
      }
      entries = entries.filter(([key]) => key in this.value)
      if (!entries.length) return

      for (const [key, value] of entries) {
        proxy[key] = value
      }
    },
    /**
     * 选取指定属性设置(若指定属性不存在于formData则会被忽略)
     * @param {Object} val 需要更新的数据
     * @param {String | Array<String>} pickProperties 需要选取的属性
     */
    setPick(proxy, val, pickProperties) {
      let entries
      if (Array.isArray(pickProperties)) {
        entries = Object.entries(val).filter(([key]) => pickProperties.includes(key))
      }
      else if (typeof pickProperties === 'string') {
        entries = Object.entries(val).filter(([key]) => key === pickProperties)
      }
      else {
        throw new TypeError('PickProperties param must be string or array')
      }
      entries = entries.filter(([key]) => key in this.value)
      if (!entries.length) return

      for (const [key, value] of entries) {
        proxy[key] = value
      }
    },
    /**
     * 只设置非空属性，值为undefined或null时略过(不存在于formData的属性同样会被忽略)
     * @param {Object} val 需要更新的数据
     */
    setIfPresent(proxy, val) {
      const entries = Object.entries(val).filter(([key, value]) => key in this.value && value !== undefined && value !== null)
      if (!entries.length) return

      for (const [key, value] of entries) {
        proxy[key] = value
      }
    },
    /**
     * 只在属性满足指定条件时设置(不存在于formData的属性会被忽略)
     * @param {Object} val 需要更新的数据
     * @param {Function} predicate 测试函数，参数为 [属性值, 属性名]
     */
    setIf(proxy, val, predicate) {
      const entries = Object.entries(val).filter(([key, value]) => key in this.value && predicate(value, key))
      if (!entries.length) return

      for (const [key, value] of entries) {
        proxy[key] = value
      }
    },
    /**
     * 为指定属性设置格式器，使用 [$属性名] 访问格式化结果
     * @param {String} property 属性名
     * @param {Function} formatter 格式器，入参为属性值，返参为格式化后的属性值
     * @returns 代理本身
     */
    format(proxy, property, formatter) {
      if (typeof property !== 'string') {
        throw new TypeError(`Property "${property}" must be string`)
      }
      if (typeof formatter !== 'function') {
        throw new TypeError('Formatter param must be function')
      }
      if (!PROPERTIES.has(property)) {
        console.warn(`Unknown property "${property}" formatter`)
        return
      }
      FORMATTERS.set(property, formatter)
      this.value[`$${property}`] = formatter(this.value[property])
      return proxy
    },
    // 返回属性名数组，受设置的group影响
    keys(proxy) {
      return Object.keys(proxy.value)
    },
    // 返回属性值数组，受设置的group影响
    values(proxy) {
      return Object.values(proxy.value)
    },
    // 返回属性名和属性值元组的数组，受设置的group影响
    entries(proxy) {
      return Object.entries(proxy.value)
    },
    /**
     * 条件为真时只返回指定属性
     * tip: 若多个条件同时成立，将按设置顺序返回首个命中的组
     * @param {Function} predicate 测试函数
     * @param {Array<String>} properties 属性名
     * @returns 代理本身
     */
    group(proxy, predicate, properties) {
      const _properties = []
      for (const property of properties) {
        if (!PROPERTIES.has(property)) {
          console.warn(`Unknown property "${property}" in group`)
          continue
        }
        _properties.push(property)
      }
      GROUPS.set(predicate, _properties)
      return proxy
    },
    ...customFunc,
  }

  const KEYWORDS = new Set(Object.keys(FUNC).concat('value'))

  ;(() => {
    if (typeof _defaultValue !== 'object' || _defaultValue === null || Array.isArray(_defaultValue)) {
      throw new TypeError('Value must be an object')
    }
    const keys = Object.keys(_defaultValue)
    for (const key of keys) {
      if (key.startsWith('$')) {
        throw new Error(`Key "${key}" cannot start with "$"`)
      }
    }
    const intersection = new Set(keys).intersection(KEYWORDS)
    if (intersection.size) {
      throw new Error(`Value must not contain reserved keywords: ${Array.from(intersection)}`)
    }

    Object.keys(_defaultValue).forEach(item => PROPERTIES.add(item))
  })()

  const formData = ref(defaultValue)

  let formDataProxy

  const valueProxy = new Proxy(formData.value, {
    getOwnPropertyDescriptor(target, prop) {
      const desc = Reflect.getOwnPropertyDescriptor(target, prop)
      if (isFormatterKey(prop)) {
        desc.enumerable = false
      }
      return desc
    },
    ownKeys(target) {
      const keys = Reflect.ownKeys(target)
      for (const [predicate, properties] of GROUPS.entries()) {
        if (predicate()) {
          const set = PROPERTIES.difference(new Set(properties))
          return keys.filter(key => !set.has(key))
        }
      }
      return keys
    },
    get(target, property, receiver) {
      if (property in FUNC) {
        // TODO 更多测试
        return FUNC[property].bind(formData, formDataProxy)
      }
      return Reflect.get(target, property, receiver)
    },
    set(target, property, value, receiver) {
      // console.log('value', property, value)
      if (isFormatterKey(property)) {
        throw new Error(`${property} is readonly`)
      }
      if (FORMATTERS.has(property)) {
        target[`$${property}`] = FORMATTERS.get(property)(value)
      }
      return Reflect.set(target, property, value, receiver)
    },
  })

  formDataProxy = new Proxy(formData, {
    get(target, property, receiver) {
      if (property in target.value) {
        return Reflect.get(target.value, property, receiver)
      }
      if (property === 'value') {
        return valueProxy
      }
      if (property in FUNC) {
        return FUNC[property].bind(target, receiver)
      }
      return Reflect.get(target, property, receiver)
    },
    set(target, property, value, receiver) {
      if (isFormatterKey(property) || KEYWORDS.has(property)) {
        throw new Error(`Property "${property}" is readonly`)
      }
      if (property in target.value) {
        // console.log('direct', property, value)
        if (FORMATTERS.has(property)) {
          target.value[`$${property}`] = FORMATTERS.get(property)(value)
        }
        return Reflect.set(target.value, property, value, receiver)
      }
      return Reflect.set(target, property, value, receiver)
    },
  })

  return formDataProxy
}
